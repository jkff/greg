#!/bin/sh

java -jar `dirname 0`/bin/greg-server-0.1.jar
