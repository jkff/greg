package org.greg.server;

public interface Clock {
    PreciseDateTime now();
}
