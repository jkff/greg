package org.greg.client;

class Record {
    public PreciseDateTime timestamp;
    public String message;
}
