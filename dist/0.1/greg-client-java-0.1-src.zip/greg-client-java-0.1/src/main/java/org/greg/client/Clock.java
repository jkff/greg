package org.greg.client;

interface Clock {
    PreciseDateTime now();
}
